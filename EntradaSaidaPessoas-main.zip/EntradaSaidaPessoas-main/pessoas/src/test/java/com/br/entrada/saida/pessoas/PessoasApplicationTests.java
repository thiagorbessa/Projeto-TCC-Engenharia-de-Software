package com.br.entrada.saida.pessoas;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PessoasApplicationTests {

	@Test
	void contextLoads() {
	}

}
